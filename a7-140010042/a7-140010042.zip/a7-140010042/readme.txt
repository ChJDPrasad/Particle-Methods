run 'sh a7-140010042.sh' in terminal.
